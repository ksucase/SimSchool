SimSchool
=========

Starter Program for exploring Object-Oriented Programming Concepts